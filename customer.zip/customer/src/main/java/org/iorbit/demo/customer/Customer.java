/**
 * SMART - State Machine ARchiTecture
 *
 * Copyright (C) 2012 Individual contributors as indicated by
 * the @authors tag
 *
 * This file is a part of SMART.
 *
 * SMART is a free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * SMART is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * */
 
/**
 * ************************************************************
 * HEADERS
 * ************************************************************
 * File:                org.iorbit.demo.customer.Customer
 * Revision:            1.0
 * Date:                09-09-2013
 *
 * ************************************************************
 * REVISIONS
 * ************************************************************
 * A customer to be displayed to the world
 *
 * ************************************************************
 * */

package org.iorbit.demo.customer;

public class Customer implements java.io.Serializable
{
    private String customerName;
 //   private String contact;
    private String city;
    private String state;
    private String pincode;
    private String email;
    private String phoneNum;
    private String deviceType;
    private Float lat;
    private Float lng;
    private String deviceId;
    private String street;

    public Customer()
    {
    }

    public String getCustomerName() { return customerName; }
    public String getStreet() { return street; }
    public String getCity() { return city; }
    public String getState() { return state; }
    public String getPinCode() { return pincode; }
    public String getEmail() { return email; }
    public String getPhoneNum() { return phoneNum; }
    public String getDeviceType() { return deviceType; }
    public Float getLatitude() { return lat; }
    public Float getLongitude() { return lng; }
    public String getDeviceId() { return deviceId; }
}

